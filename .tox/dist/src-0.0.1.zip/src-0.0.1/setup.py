from setuptools import setup, find_packages

setup(
    name = "src",
    version="0.0.1",
    description = "wine quality package",
    author="ak",
    packages=find_packages(),
    license= "MIT"
)